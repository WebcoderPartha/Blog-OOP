<?php
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "db_blog");
define('title', "My Persional Blog");
define('keyword', 'Blog, CMS');

